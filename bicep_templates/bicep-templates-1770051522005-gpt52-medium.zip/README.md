# Bicep Templates for Deploy Front Door + Dual App Services + PostgreSQL + Storage + Private Key Vault (Private Link) to Azure
Generated: 2026-02-02, 11:55:15 a.m.

## Deployment Instructions

1. Review and customize parameters in main.bicep
2. Deploy with Azure CLI:
   ```bash
   az login
   az group create --name <rg-name> --location <location>
   az deployment group create --resource-group <rg-name> --template-file main.bicep
   ```

## Files Included
- main.bicep: Orchestrates deployment of networking, data, app, edge routing, private link for Key Vault, and observability.
- modules/vnet.bicep: Creates a VNet with a delegated subnet for App Service VNet integration and a subnet for Private Endpoints (policies disabled).
- modules/loganalytics.bicep: Creates a Log Analytics workspace for centralized logging and querying (KQL).
- modules/appinsights.bicep: Creates workspace-based Application Insights connected to Log Analytics.
- modules/storage.bicep: Creates a Storage Account (GPv2) and a private blob container for images.
- modules/postgresql.bicep: Creates Azure Database for PostgreSQL Flexible Server with public network enabled (adjust for private access if required).
- modules/keyvault.bicep: Creates a Key Vault with RBAC enabled and Public Network Access disabled (for Private Link only).
- modules/privatedns.bicep: Creates a Private DNS Zone for Key Vault Private Link and links it to the VNet.
- modules/privateendpoint-keyvault.bicep: Creates a Private Endpoint for Key Vault and attaches it to the Private DNS Zone via privateDnsZoneGroup.
- modules/appservice.bicep: Creates an App Service Plan (Premium for VNet integration), two Web Apps with system-assigned managed identity, and configures VNet integration + basic app settings for telemetry and dependency endpoints.
- modules/frontdoor.bicep: Deploys Azure Front Door Standard with two origins (frontend and API) and routes / to frontend and /api/* to API over HTTPS.
- modules/monitor-diagnostics.bicep: Configures diagnostic settings to send logs/metrics from App Services, Key Vault, and Front Door to Log Analytics.
