# Bicep Templates for Deploy Machine Learning Pipeline to Azure
Generated: 2026-02-01, 3:59:14 p.m.

## Deployment Instructions

1. Review and customize parameters in main.bicep
2. Deploy with Azure CLI:
   ```bash
   az login
   az group create --name <rg-name> --location <location>
   az deployment group create --resource-group <rg-name> --template-file main.bicep
   ```

## Files Included
- main.bicep: Orchestrates deployment of all resources
- modules/eventhubs.bicep: Deploys Event Hubs namespace and event hub
- modules/datalake.bicep: Deploys Gen2 Data Lake Storage account
- modules/amlWorkspace.bicep: Deploys AML Workspace with managed identity
- modules/containerRegistry.bicep: Deploys Azure Container Registry
- modules/apiManagement.bicep: Deploys API Management Service
- modules/keyVault.bicep: Deploys Azure Key Vault with access policies
- modules/applicationInsights.bicep: Deploys Application Insights resource
