# Bicep Templates for Deploy Machine Learning Pipeline Architecture to Azure
Generated: 2026-02-01, 4:04:04 p.m.

## Deployment Instructions

1. Review and customize parameters in main.bicep
2. Deploy with Azure CLI:
   ```bash
   az login
   az group create --name <rg-name> --location <location>
   az deployment group create --resource-group <rg-name> --template-file main.bicep
   ```

## Files Included
- main.bicep: Orchestrates all ML pipeline resources and module deployments.
- eventHub.bicep: Event Hubs namespace and hub for real-time ingestion.
- dataLake.bicep: Azure Data Lake Storage Gen2 account and container.
- acr.bicep: Azure Container Registry for ML model images.
- keyVault.bicep: Azure Key Vault for secrets and credentials.
- aml.bicep: Azure Machine Learning Workspace setup and links.
- apiManagement.bicep: API Management instance for inference endpoints.
- appInsights.bicep: Application Insights for monitoring API and inference.
