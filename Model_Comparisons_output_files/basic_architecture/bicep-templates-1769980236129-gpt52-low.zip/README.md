# Bicep Templates for Deploy ML Pipeline (Ingestion, Training, Inference) to Azure
Generated: 2026-02-01, 4:10:25 p.m.

## Deployment Instructions

1. Review and customize parameters in main.bicep
2. Deploy with Azure CLI:
   ```bash
   az login
   az group create --name <rg-name> --location <location>
   az deployment group create --resource-group <rg-name> --template-file main.bicep
   ```

## Files Included
- main.bicep: Orchestration template deploying all services (except Entra app registrations).
- modules/loganalytics.bicep: Log Analytics workspace for centralized monitoring and queries.
- modules/appinsights.bicep: Application Insights connected to Log Analytics workspace (workspace-based).
- modules/storage.bicep: Data Lake Storage Gen2 for raw/curated/training zones.
- modules/keyvault.bicep: Key Vault for secrets/configuration (RBAC authorization enabled).
- modules/eventhubs.bicep: Event Hubs namespace + event hub with Capture to ADLS Gen2 raw container.
- modules/cosmos.bicep: Cosmos DB account (SQL API) for inference metadata/request context.
- modules/datafactory.bicep: Azure Data Factory with managed identity for orchestration of raw->curated and AML triggers.
- modules/acr.bicep: Azure Container Registry for training/inference images.
- modules/aml.bicep: Azure ML workspace wired to Storage, ACR, Key Vault, Application Insights, and Log Analytics.
- modules/appservice.bicep: App Service Plan + Web App with system-assigned identity and App Insights + Key Vault settings.
- modules/functions.bicep: Function App (Consumption by default) with system-assigned identity and App Insights + Key Vault settings.
- modules/apim.bicep: API Management instance to front the inference API and enforce auth (policies configured post-deploy).
- modules/rbac.bicep: Assign minimal roles for managed identities to read Key Vault secrets. Extend with Storage/Cosmos/AML roles as needed for your app/pipelines.
