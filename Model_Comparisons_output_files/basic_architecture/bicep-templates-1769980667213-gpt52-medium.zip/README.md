# Bicep Templates for Deploy ML Pipeline (Ingestion → Training → Inference) to Azure
Generated: 2026-02-01, 4:17:29 p.m.

## Deployment Instructions

1. Review and customize parameters in main.bicep
2. Deploy with Azure CLI:
   ```bash
   az login
   az group create --name <rg-name> --location <location>
   az deployment group create --resource-group <rg-name> --template-file main.bicep
   ```

## Files Included
- main.bicep: Orchestrates deployment of all services and shared naming/outputs.
- modules/logAnalytics.bicep: Creates Log Analytics workspace for centralized logging and alert queries.
- modules/appInsights.bicep: Creates workspace-based Application Insights connected to Log Analytics.
- modules/keyVault.bicep: Creates Key Vault with RBAC authorization enabled (recommended).
- modules/dataLake.bicep: Creates StorageV2 with hierarchical namespace and file systems for raw/curated/features.
- modules/eventHubs.bicep: Creates Event Hubs namespace, event hub, consumer group, and listen authorization rule.
- modules/cosmosDb.bicep: Creates Cosmos DB account (SQL API), database, and container for predictions.
- modules/acr.bicep: Creates Azure Container Registry for AML model serving images.
- modules/azureMachineLearning.bicep: Creates Azure ML workspace wired to ADLS/Key Vault/App Insights/ACR and enables system-assigned identity.
- modules/functionApp.bicep: Creates Function App (Consumption) with system-assigned identity and App Insights integration. Event Hub/Key Vault connection values are expected to be referenced via Key Vault secret URIs post-deploy or by the application.
- modules/appService.bicep: Creates App Service plan + Web App with system-assigned identity and App Insights integration.
- modules/apiManagement.bicep: Creates API Management instance. API definitions and JWT validation policies are applied post-deployment (recommended).
- modules/monitor.bicep: Creates a basic Action Group (optional email) and example scheduled-query alerts against Log Analytics/App Insights.
- modules/connections.bicep: Implements cross-service connections using RBAC role assignments and stores sensitive connection details in Key Vault (Event Hubs listen, Cosmos endpoint/key).
